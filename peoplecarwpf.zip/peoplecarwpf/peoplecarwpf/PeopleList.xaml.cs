﻿using peoplecarlibrary.Models;
using peoplecarlibrary.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace peoplecarwpf
{
    /// <summary>
    /// Interaction logic for PeopleList.xaml
    /// </summary>
    public partial class PeopleList : Page
    {
        PeopleListViewModel _vm;
        public PeopleList()
        {
            InitializeComponent();
            _vm = new PeopleListViewModel();
        }

        private void btn_save_edited_people_Click(object sender, RoutedEventArgs e)
        {
            _vm.Update(lb_peoples.SelectedItem as People);

        }
    }
}
