﻿
using Microsoft.Extensions.DependencyInjection;
using peoplecarlibrary.Models;
using peoplecarlibrary.Services;
using peoplecarwpf;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace peoplecarlibrary.ViewModels
{
    public class PeopleListViewModel
    {
        private IAppService appService;
        public ObservableCollection<People> peoples;

        public PeopleListViewModel()
        {
            appService = App.Current.Services.GetService<IAppService>();
            peoples = appService.Get_All_People();
        }

        public void Update(People people)
        {
            appService.Update_People(people);
        }
    }
}
