﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace peoplecarlibrary.Models
{
    public class Context : DbContext
    {
        public DbSet<Car> car { get; set; }
        public DbSet<People> people { get; set; }
        public DbSet<Peoplecar> peoplecar { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            string cs = "server = localhost;userid=root;password=;database=peoplecar";

            optionsBuilder.UseMySql(cs, ServerVersion.AutoDetect(cs));
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Peoplecar>().HasKey(pc => new { pc.carid, pc.peopleid });
        }
    }
}
