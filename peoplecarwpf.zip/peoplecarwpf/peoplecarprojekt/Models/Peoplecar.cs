﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace peoplecarlibrary.Models
{
    public class Peoplecar
    {
        public int peopleid { get; set; }
        public People people { get; set; } = null!;
        public int carid { get; set; }
        public Car car { get; set; } = null!;

    }
}
