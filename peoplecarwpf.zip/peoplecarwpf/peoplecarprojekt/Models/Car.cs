﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace peoplecarlibrary.Models
{
    public class Car
    {
        public int id { get; set; }

        public string brand { get; set; }
        public string model{ get; set; }
        public int year { get; set; }
    
    }
}
