﻿using peoplecarlibrary.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace peoplecarlibrary.Services
{
    public interface IAppService
    {
         public Car Get_Car_By_Id(int id);

        public ObservableCollection<Car> Get_All_Car();

        public People Get_People_By_Id(int id);

        public ObservableCollection<People> Get_All_People();

        public void Update_People(People people);



    }
}
