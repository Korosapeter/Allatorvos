﻿using Microsoft.EntityFrameworkCore;
using peoplecarlibrary.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace peoplecarlibrary.Services
{
    public class AppService : IAppService
    {
        Context _context;
        public AppService() 
        { 

            _context = new Context();
        
        }

        public ObservableCollection<Car> Get_All_Car()
        {
            return new ObservableCollection<Car>((from c in _context.car select c).ToList());
        }

        public ObservableCollection<People> Get_All_People()
        {
            return new ObservableCollection<People>((from f in _context.people.Include(i => i.peoplecars).ThenInclude(i => i.car) select f).ToList());
        }

        public Car Get_Car_By_Id(int id)
        {
            return(from c in _context.car where c.id== id select c).FirstOrDefault();
        }

        public People Get_People_By_Id(int id)
        {
            return (from c in _context.people where c.id == id select c).FirstOrDefault();
        }

        public void Update_People(People people)
        {
            _context.Update(people);
            _context.SaveChanges();
        }
    }
}
