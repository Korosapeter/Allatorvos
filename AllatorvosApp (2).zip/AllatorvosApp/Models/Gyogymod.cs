namespace AllatorvosLibrary.Models
{
    public class Gyogymod
    {
        public int Id { get; set; }
        public string Nev { get; set; }
    }
}