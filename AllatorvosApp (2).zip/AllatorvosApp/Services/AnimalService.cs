using System.Collections.Generic;
using System.Linq;
using AllatorvosLibrary.Models;

namespace AllatorvosApp.Services
{
    public class AnimalService
    {
        private readonly Allatorvos_Context _context;

        public AnimalService(Allatorvos_Context context)
        {
            _context = context;
        }

        public void AddAnimal(Allat animal)
        {
            _context.Allatok.Add(animal);
            _context.SaveChanges();
        }

        public List<Allat> GetAllAnimals()
        {
            return _context.Allatok.ToList();
        }
    }
}