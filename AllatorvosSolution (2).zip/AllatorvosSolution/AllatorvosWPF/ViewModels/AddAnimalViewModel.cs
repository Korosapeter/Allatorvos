using System.Windows.Input;
using AllatorvosLibrary.Models;
using AllatorvosApp.Services;
using AllatorvosApp.Commands;

namespace AllatorvosApp.ViewModels
{
    public class AddAnimalViewModel : BaseViewModel
    {
        private readonly AnimalService _animalService;
        public string Nev { get; set; }
        public ICommand AddAnimalCommand { get; }

        public AddAnimalViewModel(AnimalService animalService)
        {
            _animalService = animalService;
            AddAnimalCommand = new RelayCommand(AddAnimal);
        }

        private void AddAnimal()
        {
            var newAnimal = new Allat { Nev = Nev };
            _animalService.AddAnimal(newAnimal);
        }
    }
}