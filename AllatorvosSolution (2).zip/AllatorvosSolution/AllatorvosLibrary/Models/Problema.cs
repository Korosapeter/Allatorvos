namespace AllatorvosLibrary.Models
{
    public class Problema
    {
        public int Id { get; set; }
        public string Nev { get; set; }
        public string Leiras { get; set; }
        public Gyogymod Gyogymod { get; set; }
    }
}