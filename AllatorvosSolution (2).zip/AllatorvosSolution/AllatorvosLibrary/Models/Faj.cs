namespace AllatorvosLibrary.Models
{
    public class Faj
    {
        public int Id { get; set; }
        public string Fajta { get; set; }
    }
}