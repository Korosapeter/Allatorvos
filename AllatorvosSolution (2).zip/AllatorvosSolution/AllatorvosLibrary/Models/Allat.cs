using System;

namespace AllatorvosLibrary.Models
{
    public class Allat
    {
        public int Id { get; set; }
        public string Nev { get; set; }
        public Faj Faj { get; set; }
        public Problema Problema { get; set; }
    }
}