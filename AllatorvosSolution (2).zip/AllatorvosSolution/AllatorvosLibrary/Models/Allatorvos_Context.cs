using Microsoft.EntityFrameworkCore;

namespace AllatorvosLibrary.Models
{
    public class Allatorvos_Context : DbContext
    {
        public DbSet<Allat> Allatok { get; set; }
        public DbSet<Faj> Fajok { get; set; }
        public DbSet<Gyogymod> Gyogymodok { get; set; }
        public DbSet<Problema> Problemak { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            string cs = "server=localhost;userid=root;password=;database=Allatorvosirendelo";
            optionsBuilder.UseMySql(cs, ServerVersion.AutoDetect(cs));
        }
    }
}