﻿using Api_csibesz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace asdasdsadasd.Models
{
    public class Root
    {
        public List<Post> posts { get; set; }
    }
}
