﻿namespace Api_csibesz
{
    public class Post
    {
        public int id { get; set; }
        public string title { get; set; }
        public string body { get; set; }
        public List<string> tags { get; set; }
    }
}
