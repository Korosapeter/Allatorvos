using Api_csibesz;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace asdasdsadasd
{
    public interface IDataService
    {
        Task<IEnumerable<Post>> GetDataAsync();
    }
}
