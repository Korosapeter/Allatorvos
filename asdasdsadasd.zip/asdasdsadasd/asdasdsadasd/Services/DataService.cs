using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using Api_csibesz;
using asdasdsadasd.Models;
using Newtonsoft.Json;

namespace asdasdsadasd
{
    public class DataService : IDataService
    {
        private readonly HttpClient _httpClient;

        public DataService()
        {
            _httpClient = new HttpClient();
        }

        public async Task<IEnumerable<Post>> GetDataAsync()
        {
            var response = await _httpClient.GetStringAsync("https://dummyjson.com/posts");
            var rootObject = JsonConvert.DeserializeObject<Root>(response);
            return rootObject.posts;
        }
    }
}
