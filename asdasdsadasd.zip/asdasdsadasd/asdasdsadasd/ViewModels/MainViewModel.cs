using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows.Input;
using Api_csibesz;
using asdasdsadasd.Commands;

namespace asdasdsadasd.ViewModels
{
    public class MainViewModel : ViewModelBase
    {
        private readonly IDataService _dataService;
        private ObservableCollection<Post> _data;

        public ObservableCollection<Post> Data
        {
            get => _data;
            set => SetProperty(ref _data, value);
        }

        public ICommand LoadDataCommand { get; }

        public MainViewModel()
        {
            _dataService = new DataService();
            LoadDataCommand = new RelayCommand(async _ => await LoadData());
        }

        private async Task LoadData()
        {
            Data = new ObservableCollection<Post>(await _dataService.GetDataAsync());
        }
    }
}
