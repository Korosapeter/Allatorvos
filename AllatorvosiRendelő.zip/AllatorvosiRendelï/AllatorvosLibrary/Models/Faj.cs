﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AllatorvosLibrary.Models
{
    internal class Faj
    {
        public int Id { get; set; }
        public string Fajta { get; set; }
    }
}
