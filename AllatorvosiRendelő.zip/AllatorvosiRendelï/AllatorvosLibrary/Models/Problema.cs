﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AllatorvosLibrary.Models
{
    internal class Problema
    {
        public int Id { get; set; }
        public string Nev { get; set; }
        public string Liras { get; set; }
        public Gyogymod Gyogymod { get; set; }
    }
}