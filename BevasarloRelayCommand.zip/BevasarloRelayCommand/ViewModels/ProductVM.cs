﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows;
using BevasarloRelayCommand.Commands;
using BevasarloRelayCommand.Models;

namespace BevasarloRelayCommand.ViewModels
{
    public class ProductVM
    {
        public Product NewProduct { get; set; } = new();
        public ObservableCollection<Product> productsOC { get; set; }
        public RelayCommands RemoveCommand { get; set; }
        public RelayCommands AddCommand { get; set; }
        public string NewProductName { get; set; }
        public int NewProductQuantity { get; set; }

        public ProductVM()
        {
            productsOC = new ObservableCollection<Product>();
            productsOC.Add(new Product { Name = "Túró", Quantity = 3 });
            productsOC.Add(new Product { Name = "Helo", Quantity = 10 });

            RemoveCommand = new RelayCommands(c => RemoveItem(c));
            AddCommand = new RelayCommands(c => AddProduct());
        }

        public void RemoveItem(object t)
        {
            productsOC.Remove(t as Product);
        }

        public void AddProduct()
        {
            if (!string.IsNullOrEmpty(NewProductName) && NewProductQuantity > 0)
            {
                productsOC.Add(new Product { Name = NewProductName, Quantity = NewProductQuantity });
            }
        }
        public bool CanAddItem()
        {
            foreach (var item in productsOC)
            {
                if(item.Name == NewProduct.Name)
                {
                    MessageBox.Show(":(");
                    return false;
                }
            }
            return true;
        }
    }
}
